# ResumeIQ — AI Resume Analyzer

A full-stack project using Python Flask, HTML, CSS, JavaScript and the OpenAI API.

## Features
- Upload PDF or DOCX resume (maximum 5 MB)
- AI-generated resume score and summary
- Strengths, improvements and missing-section feedback
- Skills detected from the resume
- ATS-friendly suggestions
- Optional job description matching and tailoring tips
- Suggested professional summary
- Responsive interface and printable report

## Run on Windows using VS Code
1. Extract the ZIP and open `AI_Resume_Analyzer` in VS Code.
2. Open Terminal → New Terminal.
3. Create a virtual environment:
   `python -m venv venv`
4. Activate it:
   `venv\\Scripts\\activate`
5. Install packages:
   `pip install -r requirements.txt`
6. Copy `.env.example` and rename the copy to `.env`.
7. Add your API key in `.env`:
   `OPENAI_API_KEY=your_actual_api_key`
   `OPENAI_MODEL=gpt-5.5`
8. Run:
   `python app.py`
9. Visit `http://127.0.0.1:5000`.

## Notes
- Requires an OpenAI API key with API access and billing configured. API billing is separate from a ChatGPT subscription.
- Scanned/image-only PDFs may not have extractable text; use a text-based PDF or DOCX.
- Uploaded files are processed in memory and are not saved by this app.
- Scores are approximate AI feedback, not hiring predictions.
- Keep `.env` private and never upload it to GitHub.
- Before deployment, disable Flask debug mode and use a production WSGI server.
