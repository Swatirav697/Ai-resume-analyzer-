const form=document.getElementById("form"), fileInput=document.getElementById("resume"), drop=document.getElementById("drop");
const fileName=document.getElementById("fileName"), fileInfo=document.getElementById("fileInfo");
const submit=document.getElementById("submit"), loading=document.getElementById("loading");
const errorBox=document.getElementById("error"), results=document.getElementById("results");
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showError(s){errorBox.textContent=s;errorBox.classList.remove("hidden");}
function listCard(title,items){items=Array.isArray(items)?items:[];return `<article class="card"><h3>${esc(title)}</h3>${items.length?`<ul>${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`:"<p>No specific items found.</p>"}</article>`;}
function render(a){
 const score=Math.max(0,Math.min(100,Number(a.overall_score)||0)),job=a.job_match;
 results.innerHTML=`<div class="results-head"><h2>Your analysis</h2><div class="actions"><button id="print">Print report</button><button id="again">Analyze another</button></div></div>
 <div class="grid">
 <article class="card score"><div class="score-number">${score}</div><div><h3>Overall resume score</h3><p>${esc(a.summary)}</p><div class="muted">AI feedback score, not a hiring prediction.</div></div></article>
 ${job?`<article class="card"><h3>Job match score</h3><div class="job-score">${Math.max(0,Math.min(100,Number(job.match_score)||0))}%</div><p>Estimated alignment with the supplied job description.</p></article>`:`<article class="card"><h3>Professional summary suggestion</h3><p>${esc(a.rewritten_summary)}</p></article>`}
 ${listCard("Your strengths",a.strengths)}${listCard("Areas to improve",a.improvements)}
 <article class="card"><h3>Skills found</h3><div class="pills">${(a.skills||[]).length?a.skills.map(x=>`<span class="pill">${esc(x)}</span>`).join(""):"<p>No skills detected.</p>"}</div></article>
 ${listCard("Missing or unclear sections",a.missing_sections)}${listCard("ATS-friendly tips",a.ats_tips)}
 <article class="card"><h3>Suggested professional summary</h3><p>${esc(a.rewritten_summary)}</p></article>
 ${job?listCard("Matching skills",job.matching_skills):""}${job?listCard("Skills to develop",job.skills_to_develop):""}${job?listCard("How to tailor your resume",job.tailoring_tips):""}
 </div>`;
 results.classList.remove("hidden");
 document.getElementById("print").onclick=()=>window.print();
 document.getElementById("again").onclick=()=>{form.reset();results.classList.add("hidden");errorBox.classList.add("hidden");fileName.textContent="Choose a file or drag it here";fileInfo.textContent="Your resume is processed for this analysis.";window.scrollTo({top:0,behavior:"smooth"});};
}
fileInput.addEventListener("change",()=>{const f=fileInput.files[0];if(f){fileName.textContent=f.name;fileInfo.textContent=(f.size/1048576).toFixed(2)+" MB selected";}});
["dragenter","dragover"].forEach(n=>drop.addEventListener(n,e=>{e.preventDefault();drop.classList.add("drag");}));
["dragleave","drop"].forEach(n=>drop.addEventListener(n,e=>{e.preventDefault();drop.classList.remove("drag");}));
drop.addEventListener("drop",e=>{const f=e.dataTransfer.files[0];if(!f)return;if(!["pdf","docx"].includes(f.name.split(".").pop().toLowerCase()))return showError("Please choose a PDF or DOCX file.");const dt=new DataTransfer();dt.items.add(f);fileInput.files=dt.files;fileName.textContent=f.name;fileInfo.textContent=(f.size/1048576).toFixed(2)+" MB selected";});
form.addEventListener("submit",async e=>{
 e.preventDefault();errorBox.classList.add("hidden");results.classList.add("hidden");
 const f=fileInput.files[0];if(!f)return showError("Please select your resume first.");if(f.size>5*1048576)return showError("File is larger than 5 MB.");
 loading.classList.remove("hidden");submit.disabled=true;submit.firstChild.textContent="Analyzing...";
 try{const r=await fetch("/api/analyze",{method:"POST",body:new FormData(form)});const data=await r.json();if(!r.ok)throw Error(data.error||"Analysis failed.");render(data.analysis||{});results.scrollIntoView({behavior:"smooth"});}
 catch(err){showError(err.message||"Something went wrong.");}
 finally{loading.classList.add("hidden");submit.disabled=false;submit.firstChild.textContent="Analyze my resume ";}
});
