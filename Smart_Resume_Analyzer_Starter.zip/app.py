from flask import Flask
app=Flask(__name__)
@app.route('/')
def home():
    return 'Smart Resume Analyzer - Starter'
if __name__=='__main__':
    app.run(debug=True)
