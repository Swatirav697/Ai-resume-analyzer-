# Smart Resume Analyzer
This is a starter project structure.
